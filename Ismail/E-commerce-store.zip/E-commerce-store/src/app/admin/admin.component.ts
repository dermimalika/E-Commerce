import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import {Admin} from './Admin'
import { AdminService } from '../services/admin.service';
import { NgForm } from '@angular/forms';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  public admins: Admin[] | undefined;
  initAdmin:Admin ={    id:0,
    name:'',
    email:'',
    phone:'',}
  public editAdmin: Admin ={    id:0,
    name:'',
    email:'',
    phone:'',}
  public deleteAdmin: Admin={    id:0,
    name:'',
    email:'',
    phone:'',};

  constructor(private adminService: AdminService,
    @Inject(DOCUMENT) private document: Document) { }

  ngOnInit(): void {
    this.getAdmins();
  }

  public getAdmins(): void {
    this.adminService.getAdmins().subscribe(
      (response: Admin[]) => {
        this.admins = response;
        console.log(this.admins);
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
      }
    );
  }
  public onAddAdmin(addForm: NgForm): void {
    document.getElementById('add-Admin-form')!.click();
    this.adminService.addAdmin(addForm.value).subscribe(
      (response: Admin) => {
        console.log(response);
        this.getAdmins();
        addForm.reset();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
        addForm.reset();
      }
    );
  }

  public onUpdateAdmin(admin: Admin): void {
    this.adminService.updateAdmin(admin).subscribe(
      (response: Admin) => {
        console.log(response);
        this.getAdmins();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
      }
    );
  }

  public onDeleteAdmin(adminId: number): void {
    this.adminService.deleteAdmin(adminId).subscribe(
      (response: void) => {
        console.log(response);
        this.getAdmins();
      },
      (error: HttpErrorResponse) => {
        alert(error.message);
      }
    );
  }

  public searchAdmins(key: string): void {
    console.log(key);
    const results: Admin[] = [];
    for (const admin of this.admins!) {
      if (admin.name.toLowerCase().indexOf(key.toLowerCase()) !== -1
      || admin.email.toLowerCase().indexOf(key.toLowerCase()) !== -1
      || admin.phone.toLowerCase().indexOf(key.toLowerCase()) !== -1
      ) {
        results.push(admin);
      }
    }
    this.admins = results;
    if (results.length === 0 || !key) {
      this.getAdmins();
    }
  }

  public onOpenModal(admin: Admin, mode: string): void {
    const container = document.getElementById('main-container');
    const button = document.createElement('button');
    button.type = 'button';
    button.style.display = 'none';
    button.setAttribute('data-toggle', 'modal');
    if (mode === 'add') {
      button.setAttribute('data-target', '#addAdminModal');
    }
    if (mode === 'edit') {
      this.editAdmin = admin;
      button.setAttribute('data-target', '#updateAdminModal');
    }
    if (mode === 'delete') {
      this.deleteAdmin = admin;
      button.setAttribute('data-target', '#deleteAdminModal');
    }
    container!.appendChild(button);
    button.click();
  }


}
