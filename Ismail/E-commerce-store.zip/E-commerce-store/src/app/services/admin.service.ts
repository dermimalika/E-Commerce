import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Admin } from '../admin/Admin';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private apiServerUrl=environment.apiServerUrl;

  constructor(private http: HttpClient){}

  public getAdmins(): Observable<Admin[]> {
    return this.http.get<Admin[]>(`${this.apiServerUrl}/admin/all`);
  }

  public addAdmin(admin: Admin): Observable<Admin> {
    return this.http.post<Admin>(`${this.apiServerUrl}/admin/add`, admin);
  }

  public updateAdmin(admin: Admin): Observable<Admin> {
    return this.http.put<Admin>(`${this.apiServerUrl}/admin/update`, admin);
  }

  public deleteAdmin(adminId: number): Observable<void> {
    return this.http.delete<void>(`${this.apiServerUrl}/admin/delete/${adminId}`);
  }
}
