import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app.routing';

import { AppComponent } from './app.component';
import { TableListComponent } from './table-list/table-list.component';
import { StoreComponent } from './store/store.component';
import { StoreService } from './services/store.service';
import { AdminComponent } from './admin/admin.component';


@NgModule({
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,

    RouterModule,
    AppRoutingModule,
  ],
  declarations: [
    AppComponent,
    TableListComponent,
    StoreComponent,
    AdminComponent,

  ],
  providers: [StoreService],
  bootstrap: [AppComponent]
})
export class AppModule { }
